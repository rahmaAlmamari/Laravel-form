<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CREATE PRODUCTS VIEW</title>
</head>
<body>
    <form action="/products/store" method="post">
        @csrf 
        <label for="">Name :</label>
        <input type="text" name="name" id="">
        <br><br>
        <label for="">Price :</label>
        <input type="number" name="price" id="">
        <br><br>
        <input type="submit" value="ADD">
    </form>
</body>
</html>