<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT PRODUCT VIEW</title>
</head>
<body>
<form action="/products/update/{{$record->id}}" method="post">
        @csrf 
        <label for="">Name :</label>
        <input type="text" name="name" value="{{$record->name}}">
        <br><br>
        <label for="">Price :</label>
        <input type="number" name="price" value="{{$record->price}}">
        <br>
        <label for="">Status :</label>
        <input type="text" name="is_active" value="{{$record->is_active}}">
        <br><br>
        <input type="submit" value="UPDATE">
    </form>

</body>
</html>