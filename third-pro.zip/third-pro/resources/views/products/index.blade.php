<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>READ PRODUCTS VIEW</title>
</head>
<body>
    <table>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Status</th>
        </tr>
        @foreach($records as $record)
        <!--
            ($records as $record)
            ($arrayVariableFromController as $x)
        -->
        <tr>
            <td>{{$record->id}}</td>
            <td>{{$record->name}}</td>
            <td>{{$record->price}}</td>
    <!--
        {{$record->price}}
        {{$record -> columnNameFromDtatbase}}
     -->
            <td>
                @if($record->is_active == 1)
                    Active
                @else
                    InActive
                @endif
            </td>
        </tr>
        @endforeach
    </table>
</body>
</html>