<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT PRODUCT VIEW</title>
</head>
<body>
<form action="/products/update/<?php echo e($record->id); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <label for="">Name :</label>
        <input type="text" name="name" value="<?php echo e($record->name); ?>">
        <br><br>
        <label for="">Price :</label>
        <input type="number" name="price" value="<?php echo e($record->price); ?>">
        <br>
        <label for="">Status :</label>
        <input type="text" name="is_active" value="<?php echo e($record->is_active); ?>">
        <br><br>
        <input type="submit" value="UPDATE">
    </form>

</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\third-pro\resources\views/products/edit.blade.php ENDPATH**/ ?>