<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CREATE PRODUCTS VIEW</title>
</head>
<body>
    <form action="/products/store" method="post">
        <?php echo csrf_field(); ?> 
        <label for="">Name :</label>
        <input type="text" name="name" id="">
        <br><br>
        <label for="">Price :</label>
        <input type="text" name="price" id="">
        <br><br>
        <input type="submit" value="ADD">
    </form>
</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\third-pro\resources\views/products/create.blade.php ENDPATH**/ ?>