<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>READ PRODUCTS VIEW</title>
</head>
<body>
    <table>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Status</th>
        </tr>
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--
            ($records as $record)
            ($arrayVariableFromController as $x)
        -->
        <tr>
            <td><?php echo e($record->id); ?></td>
            <td><?php echo e($record->name); ?></td>
            <td><?php echo e($record->price); ?></td>
    <!--
        <?php echo e($record->price); ?>

        <?php echo e($record -> columnNameFromDtatbase); ?>

     -->
            <td>
                <?php if($record->is_active == 1): ?>
                    Active
                <?php else: ?>
                    InActive
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\Lenovo\Downloads\projects\third-pro\resources\views/products/index.blade.php ENDPATH**/ ?>