<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductsController extends Controller
{
    //function to store new data in table
    public function store(Request $request){
        $record = new Product;
        /*
        $x = new ModelName; 
        #NOTE THAT: $x will be use to add new
        data to model and every model represent 
        one record in the table so $x is mean 
        create one new record in our table
        with the data we pass from the form
        */
        $record->name = $request->name;
        $record->price = $request->price;
        /*
        $x -> columnName = $request -> inputName;
        #NOTE THAT: columnName from the database
        inputName from the form
        */
        $record->is_active = true; 
        /*
        this column not have input in the form so 
        we give it a value here ... just to know that
        we can enter value to a column in many ways
        */
        $record->save(); //this line will store our data
        return "Recored added successfully"; 
    }

    //function to read all data from database
    public function index(){
        $data['records'] = Product::all();
        /*
        #NOTE THAT: 
        $arrayName['arrayVariable'] = modelName::all();
        -----------------------------------------
        all() is laravel function that get all record from table
        */
        return view('products.index', $data);
    }
    
    //function to read specific data from database .. edit ..
    public function edit($id){
        //$data['record'] = Product::find($id);
        $data['record'] = Product::where('id', $id)->first();
        /*
        $data['record'] = Product::where('id', $id)->first();
        $arrayName['arrayVariable'] = modelName::where('columnName', $x)->first();
        #NOTE THAT:
        columnName from the database
        $x is function argumaent 
        first() is laravel function which will get the first record 
                in the database wgich match what we want
         */
        if(!$data['record'])
           return "Id you request for does not exist!!!";

        return view('products.edit', $data);
    }

    //function to update specific data from database .. update ..
    public function update(Request $request, $id){
        $record = Product::find($id);
        /*
        $x = ModelName::find($y); 
        #NOTE THAT: $x will be use to update
        data model and every model represent 
        one record in the table so $x is mean 
        update one record in our table
        with the data we pass from the form based on $y 
        and in our function $y is $id
        */
        $record->name = $request->name;
        $record->price = $request->price;
        $record->is_active = $request->is_active;
        /*
        $x -> columnName = $request -> inputName;
        #NOTE THAT: columnName from the database
        inputName from the form
        */
        $record->save(); //this line will update our data
        return "Recored updated successfully"; 
    }

    //function to delete specific data from database .. delete ..
    public function delete($id){
        $record = Product::find($id);
        $record->delete();

        return "Recored deleted successfully";
    }

}
